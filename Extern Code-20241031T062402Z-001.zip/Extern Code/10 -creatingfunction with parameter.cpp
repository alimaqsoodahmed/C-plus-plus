#include<iostream>
using namespace std;

void printCrap(int x)
{

    cout<<"BUcky fav no IS :"<<x<<endl;
}
int main() {

    printCrap(10);

return 0;

}
