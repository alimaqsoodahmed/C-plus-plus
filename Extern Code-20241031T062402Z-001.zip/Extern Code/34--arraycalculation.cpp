//34 tutorial

#include<iostream>

using namespace std;
int main()
{

    int tuna[5] = {20, 45 ,78, 23, 56};
    int sum = 0;

    for(int x =0; x<5 ;x++){

        sum+=tuna[x];
        cout<<sum<<endl;
    }



}
