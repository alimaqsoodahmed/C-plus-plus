#include<iostream>
using namespace std;

int main() {
int a = 10 ;
int b = 5;
cout<<"  sum of a and b   :  \t\t   "<<a + b<<endl;
cout<<"MINUS A frim b  : \t\t\t" << a - b<<endl;
cout<<" DIVIDE a  and B :\t\t\t" <<  a/b <<endl;
cout<<" multiply a and b :\t\t\t"<<  a*b <<endl;


    return 0;
}
