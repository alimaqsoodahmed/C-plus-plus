#include <iostream>
#include <fstream>

using namespace std;

int main()
{

 ofstream buckysfile("noonelove.txt");

 if(buckysfile.is_open()){
    cout<<" OK the file is open"<<endl;
 }else{

 cout<< "Bucky you messed up"<<endl;
 }


 buckysfile <<" OI I LOVE BEEF xz\bxzj\ \n";
 //buckysfile.close();

}
