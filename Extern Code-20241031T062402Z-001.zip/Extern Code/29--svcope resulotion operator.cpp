#include<iostream>

using namespace std;

int tuna  = 20;  //global vaiable

int main()
{
 double  tuna =80; //local variable
 cout<<::tuna<<endl;    //ueinary operator

}

