#include<iostream>

using namespace std;

int main()
{
    int bucky[5]={4,8,7,9,0};  /arry is basiclly a varibale thats store multiple values.

    cout<<bucky[3];
}
