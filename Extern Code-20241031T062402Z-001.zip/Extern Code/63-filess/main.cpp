#include <iostream>
#include <fstream>

using namespace std;

int main()
{
   ofstream buckyfile;
   buckyfile.open("tuna.txt ") ;

   buckyfile << " I LOVE TUNA AND TUNA LOVE ME and mn,mnnmnmn \n\n that a lie 9\n";

   //buckyfile.close();
}
