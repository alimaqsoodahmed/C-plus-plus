#include <iostream>
using namespace std;

int main() {
int a;
int b;
int sum ;
cout<<"  VALUE of A:   \t\t  ";
cin>>a;
cout<<"  value of b:          ";
cin>>b;
sum = a + b ;
cout<<"\n\nSUM OF AND B IS:\t\t\t";
cout<<sum;


    return 0;
}
