//12 c++ tutorial  ->>>> extern code
#include<iostream>
using namespace std;

class BuckysClass{
 public:
    void coolSaying(){
                    cout <<  "Preaching to the choir" ;
    }

};

int main() {

   BuckysClass BuckysObject;
   BuckysObject.coolSaying() ;


return 0;

}
