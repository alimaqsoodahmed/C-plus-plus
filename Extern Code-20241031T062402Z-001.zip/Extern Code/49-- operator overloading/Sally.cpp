#include "Sally.h"   //header file
#include <iostream> // input-output stream library.

using namespace std;  //standard library names without the std:: prefix.

Sally::Sally()   // Default constructor
{

}
Sally::Sally(int a)
{
//This is a parameterized constructor that initializes the member variable num with the value a

    num = a;
}

Sally  Sally::operator+(Sally aso){  //This function overloads the + operator for  the  Sally  class.
    Sally brandNew;  //It creates a new Sally object (brandNew).
    brandNew.num  = num + aso.num; //It adds the num member of the current object (this->num) to the num member of the aso object and assigns the result to brandNew.num.
    return (brandNew);

}
