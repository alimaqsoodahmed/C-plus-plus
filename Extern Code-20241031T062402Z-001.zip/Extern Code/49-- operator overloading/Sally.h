#ifndef SALLY_H
#define SALLY_H


class Sally
{
    public:
        int num;
        Sally();
       Sally(int );
  Sally operator + (Sally);  //operator overloader
};;

#endif // SALLY_H
