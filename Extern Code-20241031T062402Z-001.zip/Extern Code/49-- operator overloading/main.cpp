#include <iostream>
#include "Sally.h"
using namespace std;

int main()
{    //create two SAlly object a b

    Sally a(34);
    Sally b(21);
    Sally c;

    //c = a.add(b);
    c = a + b ;  //It then uses the overloaded + operator to add these objects,
    cout<<c.num<<endl;
}

//-------------------------------------------------------------------------------------------------------------
/** \brief
 []  (Array subscript)
()  (Function call)
->  (Member access through pointer)
*   (Pointer dereference)
&   (Address-of)
,   (Comma)
new  (Allocate memory)
delete  (Deallocate memory)
new[]  (Allocate array)
delete[]  (Deallocate array)
 *
 */
