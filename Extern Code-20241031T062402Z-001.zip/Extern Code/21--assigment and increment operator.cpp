#include<iostream>
using namespace std;
int main()
{
 int x  =10;

 //  x /=3;

 cout<<x--<<endl;
   //cout<<++x<<endl;

  //cout<<x++<<endl;
cout<<x<<endl;
x--;
x--;
cout<<x;
return 0;
}
