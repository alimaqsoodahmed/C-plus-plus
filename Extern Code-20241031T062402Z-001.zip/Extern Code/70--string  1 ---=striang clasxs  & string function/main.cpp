#include <iostream>  //70 --string 1
#include<string>
using namespace std;

int main()
{
 string  s1 =  "ALIIS NABJS" ;
 cout<<  s1.at(3) << endl ;



 for(int x =0; x<s1.length(); x++){


    cout<< s1.at(x);
 }

}

  /*string s1("hampster  ");
  string s2;
  string s3;

  s2  =s1 ;
  s3.assign(s1);

  cout <<s1  << s2  <<s3<<endl;
}




/*   string x;
   //cin >> bucky;  //cin only read small piece of data till space then use getline
   getline(cin ,x);

   cout <<  " the string i entered is:\t\t   " << x <<endl;    */
