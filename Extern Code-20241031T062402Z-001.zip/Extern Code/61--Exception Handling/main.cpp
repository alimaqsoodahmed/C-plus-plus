#include <iostream>
using namespace std;

int main()
{

  try{
      int momsAge = 73;
      int sonsAge = 735;

      if(sonsAge > momsAge){
        throw 99;
        }
  }catch(int x){
  cout<< "son can not be older than mom , error nUmber:"<<x<<endl;}



}
