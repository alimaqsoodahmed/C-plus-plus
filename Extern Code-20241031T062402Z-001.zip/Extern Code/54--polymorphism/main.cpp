#include <iostream>
using namespace std;

class Enemy{
   protected:
       int attackPower;

   public:
    void settAttackPower(int a){
     attackPower = a;

    }

};
class Ninja: public Enemy{
  public:
      void attack()

      {
          cout<<"i am a ninja chop--"<<attackPower<<endl;
      }

};

class Monster: public Enemy{
  public:
      void attack()

      {
          cout<<"Monster must attack you --"<<attackPower<<endl;
      }

};

int main()
{

   Ninja n;
   Monster m;
   Enemy *enemy1 =  &n; //bcz ninja is of type  enemy ,thsi is valiud
   Enemy *enemy2 =  &m;//anything a monster can do , enemy can do..

   enemy1->settAttackPower(29);   //ninja is jusrt moiore specific type of ninja
      enemy2->settAttackPower(99);   //every enemy has setattackpower
      n.attack();   //cant use enemy1 bcz its type enemy
      m.attack();   //Enemy classes doesnot have attack
      return 0;   //virtual memeber can make it even easier
}
