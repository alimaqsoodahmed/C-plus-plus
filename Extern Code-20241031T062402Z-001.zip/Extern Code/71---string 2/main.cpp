#include <iostream>
#include <string>  //string sub string  swapping
using namespace std;

int main()
{
   string s1(" h    am isspam oh yes i am ");

   cout<<s1.rfind("am") <<endl;


}
/*string  s1(" OMG i think i am pregyy!!");
  cout<<s1.substr(19 ,7)<<endl;


   string one ("APPLLES");
  string two  ("beans");


  cout<<one <<two  <<endl;

  one.swap(two);

cout<<one <<two  <<endl;





  */
