#include <iostream>
using namespace std;

int main(){
       if(2>4){         //test  a condition of if statment



    cout<<"ALI IS AWESOME::";

   }
return 0;

}
