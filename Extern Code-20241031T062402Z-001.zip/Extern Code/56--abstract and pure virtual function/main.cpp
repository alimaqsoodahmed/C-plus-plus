#include <iostream>
using namespace std;

class Enemy{
  public:          // also absrtact function
      virtual void attack()= 0;//pure virtual function
};
class Ninja: public Enemy{  //class that inherit virtual member  like variable or function it a polymorphic class
public:
    void attack(){
    cout<< "  ninja attack " <<endl;
    }
};

class Monster: public  Enemy{
  public:
     void attack(){
    cout<<"  Monster attack " <<endl;
    }
};

int main()
{
Ninja n;
Monster m;
Enemy *enemy1  =&n;
Enemy  *enemy2 = &m;
enemy1->attack();
enemy2->attack();
}
