#include <iostream>
#include "Buritto.h"
using namespace std;

int main()
{
   Buritto bo;
    return 0;
}
