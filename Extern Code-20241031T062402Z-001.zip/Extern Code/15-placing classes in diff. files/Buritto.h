#ifndef BURITTO_H
#define BURITTO_H


class Buritto
{
    public:
        Buritto();


};

#endif // BURITTO_H
