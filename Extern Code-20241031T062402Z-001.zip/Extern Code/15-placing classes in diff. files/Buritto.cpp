#include "Buritto.h"
#include <iostream>

using namespace std;

Buritto::Buritto()
{
  cout<<" i am a bnananana "<<endl;
}
