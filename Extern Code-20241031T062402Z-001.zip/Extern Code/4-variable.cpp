#include <iostream>
using namespace std;

int main() {
 int a=12;
cout<<"PEINT VALE OF a: \t\t          "<<a<<endl;


    return 0;
}
