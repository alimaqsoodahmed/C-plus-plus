//60 tutorials

#include <iostream>

using namespace std;

template <class T>
class Bucky{   //template class,
    T first ,second;
public:
    Bucky(T a, T b){  //constructor
      first   = a ;
      second  = b;

    }
    T bigger();

  //T mean class template data type same as function bigger
};
 template <class T>  //return type
 T Bucky<T>::bigger(){ //bigger() function compares first and second
    return (first>second?first:second);
}
int main()
{
    Bucky <int> bo(569, 105);// type of data int
    cout<<bo.bigger();


}
