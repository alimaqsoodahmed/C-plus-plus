#ifndef POEPLE_H
#define POEPLE_H
#include<string>
#include "Birthday.h"

using namespace std;

class Poeple
{
    public:
        Poeple(string x,Birthday bo);
        void printInfo();

    private:
        string name;
        Birthday dateOfBirth;
};

#endif // POEPLE_H
