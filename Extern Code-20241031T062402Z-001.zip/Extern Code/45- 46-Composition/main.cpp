#include <iostream>
#include "Poeple.h"

#include "Birthday.h"
using namespace std;

int main()
{
    Birthday birthObj(12,28,2000);

    Poeple buckyRoberts("ALI THE KING ",birthObj);
    buckyRoberts.printInfo();

}
