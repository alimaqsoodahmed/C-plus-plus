#include "Poeple.h"

#include "Birthday.h"
#include <iostream>
using namespace std;

Poeple::Poeple(string x ,Birthday bo) //member inilization
:name(x), dateOfBirth(bo)
{

}

void Poeple::printInfo()
{

    cout<<name<<"was  born on";
    dateOfBirth.printDate();
}
