//base class

#include "Mother.h"
#include "Daughter.h"
#include <iostream>
using namespace std;
Mother::Mother()
{
}

void Mother::sayName()
{
    cout<<"I am  a ali "<<endl;

}


