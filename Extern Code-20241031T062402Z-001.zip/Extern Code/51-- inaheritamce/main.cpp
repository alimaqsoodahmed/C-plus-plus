#include <iostream>
#include "Mother.h"
#include "Daughter.h"
using namespace std;

int main()
{
   Mother mom;
   mom.sayName();


  Daughter tina;
  tina.sayName();

}
