#ifndef MOTHER_H
#define MOTHER_H


class Mother
{
    public:
        Mother();
        void sayName();  //function in mother class



};

#endif // MOTHER_H
