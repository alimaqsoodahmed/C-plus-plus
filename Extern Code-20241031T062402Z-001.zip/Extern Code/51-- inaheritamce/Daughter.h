#ifndef DAUGHTER_H
#define DAUGHTER_H


class Daughter: public Mother  //inherit all from mother a base class  not all --but function
{
    public:
        Daughter();



};

#endif // DAUGHTER_H
