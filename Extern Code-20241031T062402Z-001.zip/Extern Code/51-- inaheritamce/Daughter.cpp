//derived class
#include <iostream>
#include "Mother.h"
#include "Daughter.h"
using namespace std;
Daughter::Daughter()
{

}

