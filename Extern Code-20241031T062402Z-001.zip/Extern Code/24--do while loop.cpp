//24 tutorial
#include<iostream>
using namespace std;
int main()
{
  int x = -111;
  do{
    cout<<x<<endl;
    x++;
  }while(x<10);
}
