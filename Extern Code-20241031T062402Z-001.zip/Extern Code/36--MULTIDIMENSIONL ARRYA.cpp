#include<iostream>

using namespace std;


int main()
{
    int sally[2][3]  = {{2,3,4},{7,8,9,}}; //[row] [column]
          //2 ,3 , 4
        //7 ,8 ,9
     cout<<sally[1][2];
}




