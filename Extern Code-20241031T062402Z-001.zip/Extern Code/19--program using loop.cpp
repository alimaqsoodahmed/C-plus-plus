//19 tutorial
#include<iostream>
using namespace std;
int main()
{
int x = 1;
int number;
int total = 0;
while(x<=5){


    cout<<"NO  IS:\t  "<< "   ";
    cin>>number;
    total = total + number;
    x++;
}

cout<<"THE TOTAL IS:"<<total;


return 0;
}
