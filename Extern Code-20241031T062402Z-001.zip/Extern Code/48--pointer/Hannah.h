#ifndef HANNAH_H
#define HANNAH_H


class Hannah
{
    public:
        Hannah(int);
        void printCrap();

    private:
        int h;
};

#endif // HANNAH_H
