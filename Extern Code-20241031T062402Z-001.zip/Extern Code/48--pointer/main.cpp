#include <iostream>
#include "Hannah.h"
using namespace std;

int main()
{

  Hannah ho(23);
  ho.printCrap();

}
