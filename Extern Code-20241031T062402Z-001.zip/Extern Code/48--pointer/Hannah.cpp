#include "Hannah.h"
#include <iostream>
using namespace std;

Hannah::Hannah(int num)
:h(num)
{
}

void Hannah::printCrap()
{
    cout<<"h="<<h<<endl;   //just use private variable name print out value...
    cout<<"this->"<<this->h<<endl;  //arrow mean working with pointer stores the address of ho.
    cout<<"(*this).h" <<(*this).h<<endl;   //dereference a pointer
}
