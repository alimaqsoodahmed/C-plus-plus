#include<iostream>

using namespace std;


int addnumbers(int x, int y ,int a,int b){

int answer = x  +  y  + a + b ;

return answer ;

}
int main() {

cout<<addnumbers(25 ,25 ,25 ,25);

return 0;
}
