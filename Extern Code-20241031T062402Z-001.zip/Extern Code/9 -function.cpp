#include <iostream>
using namespace std;
void printsomething()
{
     int a = 10;
     cout<<a;




}
int main() {

cout<<printsomething;

return 0;

}

