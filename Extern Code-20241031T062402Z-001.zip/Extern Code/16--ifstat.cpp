#include<iostream>
using namespace std;
int main()
{
int x =10;
if(x != 36)
{

cout<<" ALI IS BOY::\n\n";
}else{

cout<<" HOW CA";
}

return 0;

}
