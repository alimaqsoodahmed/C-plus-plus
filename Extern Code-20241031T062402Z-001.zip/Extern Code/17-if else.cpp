#include<iostream>
using namespace std;
int main()
{
int age = 60;

if(age>=60){
    cout<<"OH YOU ARE OLDER:"<<endl;
}else
{

    cout<<"you are younger to get  ajob:"<<endl;
}


return 0;
}
