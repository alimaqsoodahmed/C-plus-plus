#ifndef SALLY_H
#define SALLY_H


class Sally
{
    public:
        Sally();
        ~Sally();

    protected:

    private:
};

#endif // SALLY_H
