#include "Sally.h"
#include <iostream>

using namespace std;

Sally::Sally()
{
    cout<<" I AM THE CONSTRUCTOR"<<endl;
}

Sally::~Sally() //no overloading
{
  cout<<"I AM THE DECONSTRUCTOR"<<endl;
}
