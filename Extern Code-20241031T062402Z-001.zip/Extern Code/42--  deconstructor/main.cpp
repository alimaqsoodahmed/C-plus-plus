#include <iostream>
#include "Sally.h"
using namespace std;

int main()
{

   Sally so;
   cout<<"omg wtf is my shoes"<<endl;
   //Deconstructor call at the end automatically

}
