#include <iostream>
using namespace std;

int main() {

cout<<"   MY name is ali \n\n \t\t\t\t\tAND \t\t\n\n\nhaloo DANJO      \n\n\n\n\n\n ";


    return 0;
}
