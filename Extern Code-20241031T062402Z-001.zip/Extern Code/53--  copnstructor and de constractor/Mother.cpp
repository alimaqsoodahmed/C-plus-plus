#include "Mother.h"
#include <iostream>
#include "Daughter.h"
using namespace std;

Mother::Mother()     //constructor
{
    cout<<" I AM THE MOTHER CONSTRUCTOR"<<endl;
}

Mother::~Mother()
{
    cout<<" MOTHER  DECONSTRUCTor"<<endl;
}
