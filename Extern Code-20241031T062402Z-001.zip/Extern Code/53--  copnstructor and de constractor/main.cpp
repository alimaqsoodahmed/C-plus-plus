#include <iostream>
#include "Daughter.h"
#include "Mother.h"
using namespace std;

int main()
{

Mother ma;

Daughter  dina;
//derived class constructor and deconsttructor =
//you cant inherit constructor and deconstructor from base class'..
}
