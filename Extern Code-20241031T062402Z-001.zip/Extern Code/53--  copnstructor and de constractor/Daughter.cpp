#include <iostream>
#include "Daughter.h"
#include "Mother.h"
using namespace std;


Daughter::Daughter()     //constructor
{
    cout<<" I AM THE Daughter CONSTRUCTOR"<<endl;
}

Daughter::~Daughter()
{
    cout<<" Daughter DECONSTRUCTor"<<endl;
}
