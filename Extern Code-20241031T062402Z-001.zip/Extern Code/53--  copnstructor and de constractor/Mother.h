#ifndef MOTHER_H
#define MOTHER_H

class Mother
{
    public:
        Mother();
        ~Mother();


};

#endif // MOTHER_H
