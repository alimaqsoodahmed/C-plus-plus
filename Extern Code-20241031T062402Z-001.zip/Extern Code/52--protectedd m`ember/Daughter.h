#ifndef DAUGHTER_H
#define DAUGHTER_H


class Daughter:public Mother
{
    public:
        void  doSomething();
};

#endif // DAUGHTER_H
