//53 tutorial
#include "Mother.h"
#include "Daughter.h"
#include <iostream>
using namespace std;

void Daughter::doSomething()
{
   publicv = 1 ;
   protectedv  = 2;
   privatev = 3 ;   //you cannot acces private from base class''..

}
