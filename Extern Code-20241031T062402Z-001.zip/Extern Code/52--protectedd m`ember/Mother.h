#ifndef MOTHER_H
#define MOTHER_H


class Mother
{
    public:
      int publicv;


    protected:
        int protectedv;

    private:
      int privatev;


};

#endif // MOTHER_H
