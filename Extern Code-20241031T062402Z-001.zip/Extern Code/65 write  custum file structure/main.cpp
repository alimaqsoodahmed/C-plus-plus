#include <iostream>
#include <fstream>
using namespace std;

int main()
{

  ofstream thefile("players.txt");
  cout<< " Enter players ID , Name and moNey "<<endl;
  cout<< "press ctrl +Z to quit\n"<<endl;

  int idnumber;
  string name;
  double money;

  while( cin>> idnumber >> name >> money){

    thefile << idnumber << ' ' <<name << ' ' <<money <<endl;

  }


}
