#include "Sally.h"
#include <iostream>

using namespace std;

Sally::Sally()
{

}

void Sally::printcrap()
{

    cout<<" did someone say streak"<<endl;
}
