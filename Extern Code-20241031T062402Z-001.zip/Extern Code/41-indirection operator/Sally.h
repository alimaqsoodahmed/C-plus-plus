#ifndef SALLY_H
#define SALLY_H


class Sally
{
    public:
        Sally();
        void printcrap();


};

#endif // SALLY_H
/*This technique is essential for managing dependencies in larger projects, as it
helps to avoid problems with multiple definitions and keeps the compiled code more efficient.*/
