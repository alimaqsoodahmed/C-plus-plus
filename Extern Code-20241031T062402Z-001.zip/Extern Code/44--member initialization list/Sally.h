#ifndef SALLY_H
#define SALLY_H


class Sally
{
    public:
        Sally(int a, int b);  //constructor take 2 value 1 to regulr varf and 2 to const.
        void print();
    private:
        int regVar;
        const int constVar;
};

#endif // SALLY_H
