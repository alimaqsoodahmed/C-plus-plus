#include "Sally.h"
#include <iostream>

using namespace std;
Sally::Sally(int a ,int b) //constructor that take 2 avr 1 to regulra avr
// and other to constant.
: regVar(a),constVar(b)  //when we have  constant variable we iniliaze through special.
{
   //body of constructor
}
void Sally::print()
    {
       cout<<"regular var is: "<< regVar <<"\nconst varibel is: "<< constVar <<endl;

    }

