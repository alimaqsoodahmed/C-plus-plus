#include <iostream>
#include <fstream>
using namespace std;

int main()
{

  ifstream thefile("players.txt");//reading data

  int id;
  string  name;
  double money;

  while(thefile >> id >> name >> money )
  {

cout<< id << "," << name <<","<<money<<endl;


  }
}




