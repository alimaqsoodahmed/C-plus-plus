#include<iostream>
using namespace std;
int main()
{

int age ;
cin>>age;

switch(age)
{
case 16:
    cout<<" HEY YOU  CAN DRive  NOw!"<<endl;
    break;

case 18:
    cout<<" GO BUY SOME LOTTO  TYICKET!"<<endl;
    break;

case 21:
    cout<<" Buy some bEER noW  NOw!"<<endl;
    break;


default:
    cout<<" sORRY YOU GET NOTHING"<<endl;

}



}
