//22  tutorial
#include<iostream>
using namespace std;
int main()
{

for(int x=1; x<10; x++)
{
    cout<<x<<endl;
}
}
