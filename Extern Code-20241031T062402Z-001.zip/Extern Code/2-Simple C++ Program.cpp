#include <iostream>
using namespace std;

int main() {

cout<<"   hallo world | ducky and wellcome to C++       ";


    return 0;
}
