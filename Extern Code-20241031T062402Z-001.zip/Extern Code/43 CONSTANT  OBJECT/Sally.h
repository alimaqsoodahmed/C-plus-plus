#ifndef SALLY_H
#define SALLY_H


class Sally
{
    public:
        Sally();
        void printShiz();
        void printShiz2() const;

    protected:

    private:
};

#endif // SALLY_H
