#include "Sally.h"
#include <iostream>
using namespace std;

Sally::Sally()
{

}
void Sally::printShiz()
{
    cout<<" I AM SO SHIOZ"<<endl;
}
void Sally::printShiz2() const
{

    cout<< "I  AM  THE  CONST "<<endl;
}
