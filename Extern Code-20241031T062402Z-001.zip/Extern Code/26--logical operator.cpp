#include<iostream>
using namespace std;
int main()
{
int age  = 23;
int money = 650;

if(age>21 && money>500)  // and --> &&-->all are true  operator  or-->  || -->anyone true
   {
       cout<<"YOu area allowed in!"<<endl;
   }



}
