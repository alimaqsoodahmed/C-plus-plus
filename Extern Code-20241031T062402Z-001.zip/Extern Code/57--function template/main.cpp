#include <iostream>
using namespace std;

template < class bucky >

bucky addCrap(bucky a , bucky b){

  return  a  +  b;

}

int main()
{
   double  x = 19,  y = 56.78 ,z;
     z=addCrap(x,y);
   cout<< z <<endl;
}
