#include<iostream>
using namespace std;
int main()
{
int bacon = 0;
while(bacon <=10){

cout<<"BACON IS GREK\t\t"<<bacon<<endl;
  bacon++;

}


return 0;
}
