#include <iostream>
#include <string>
using namespace std;

int main()
{
 string s1("hi my nmae is bucky hey and i love         bacvjodi hmm ");

    cout<<s1 <<endl;


    s1.insert(14 , "lucky  ");

          // s1.replace(14 ,5, "ali khan"  );
    //s1.erase(20);
    cout << s1 <<endl;
}
